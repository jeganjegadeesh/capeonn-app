import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_theme.dart';
import '../../data/task_models.dart';
import '../../data/task_repository.dart';
import '../../application/tasks_providers.dart';

class TaskStatusDialog extends ConsumerStatefulWidget {
  const TaskStatusDialog({
    super.key,
    required this.task,
  });

  final TaskItem task;

  @override
  ConsumerState<TaskStatusDialog> createState() => _TaskStatusDialogState();
}

class _TaskStatusDialogState extends ConsumerState<TaskStatusDialog> {
  late String _selectedStatus;
  final _reasonController = TextEditingController();
  bool _isLoading = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    final allowed = TaskStatus.allowedTransitions[widget.task.status] ?? [];
    _selectedStatus = allowed.isNotEmpty ? allowed.first : widget.task.status;
  }

  @override
  void dispose() {
    _reasonController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_selectedStatus == widget.task.status) {
      Navigator.of(context).pop();
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final repo = ref.read(taskRepositoryProvider);
      final updated = await repo.updateTaskStatus(
        widget.task.id,
        _selectedStatus,
        reason: _reasonController.text.trim().isNotEmpty ? _reasonController.text.trim() : null,
      );

      // Invalidate relevant providers
      ref.invalidate(projectTasksProvider(widget.task.projectId));
      ref.invalidate(myTasksProvider);
      ref.invalidate(taskDetailProvider(widget.task.id));
      ref.read(activeTimerProvider.notifier).checkActiveTimer();

      if (mounted) {
        Navigator.of(context).pop(updated);
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _errorMessage = e.toString().replaceAll('Exception:', '').trim();
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final allowed = TaskStatus.allowedTransitions[widget.task.status] ?? [];

    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      backgroundColor: AppColors.surface,
      title: Row(
        children: [
          Icon(Icons.swap_horiz, color: AppColors.primary),
          const SizedBox(width: 8),
          const Text('Update Task Status', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        ],
      ),
      content: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 420),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.task.title,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: AppColors.textPrimary,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Text('Current Status: ', style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: widget.task.statusColor.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: widget.task.statusColor.withValues(alpha: 0.3)),
                  ),
                  child: Text(
                    widget.task.statusDisplay,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: widget.task.statusColor,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            if (allowed.isEmpty)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.amberContainer,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  'No further lifecycle transitions are available from ${widget.task.statusDisplay}.',
                  style: TextStyle(fontSize: 12, color: AppColors.amber),
                ),
              )
            else ...[
              Text(
                'Move to:',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: allowed.map((status) {
                  final isSelected = _selectedStatus == status;
                  final color = TaskStatus.color(status);
                  return ChoiceChip(
                    label: Text(TaskStatus.label(status)),
                    selected: isSelected,
                    onSelected: (val) {
                      if (val) {
                        setState(() => _selectedStatus = status);
                      }
                    },
                    selectedColor: color.withValues(alpha: 0.2),
                    backgroundColor: AppColors.surfaceHover,
                    labelStyle: TextStyle(
                      fontSize: 12,
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                      color: isSelected ? color : AppColors.textSecondary,
                    ),
                    side: BorderSide(
                      color: isSelected ? color : AppColors.border,
                      width: isSelected ? 1.5 : 1.0,
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 16),
              Text(
                'Reason / Notes (optional):',
                style: TextStyle(fontSize: 13, color: AppColors.textSecondary),
              ),
              const SizedBox(height: 6),
              TextField(
                controller: _reasonController,
                maxLines: 2,
                decoration: InputDecoration(
                  hintText: 'Add an audit explanation for this status change...',
                  hintStyle: TextStyle(fontSize: 12, color: AppColors.textMuted),
                  filled: true,
                  fillColor: AppColors.surfaceHover,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: AppColors.border),
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                ),
                style: TextStyle(fontSize: 13, color: AppColors.textPrimary),
              ),
            ],
            if (_errorMessage != null) ...[
              const SizedBox(height: 12),
              Text(
                _errorMessage!,
                style: TextStyle(fontSize: 12, color: AppColors.rose, fontWeight: FontWeight.w500),
              ),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: _isLoading ? null : () => Navigator.of(context).pop(),
          child: Text('Cancel', style: TextStyle(color: AppColors.textSecondary)),
        ),
        if (allowed.isNotEmpty)
          ElevatedButton(
            onPressed: _isLoading ? null : _submit,
            style: ElevatedButton.styleFrom(
              backgroundColor: TaskStatus.color(_selectedStatus),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: _isLoading
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                  )
                : const Text('Update Status'),
          ),
      ],
    );
  }
}
