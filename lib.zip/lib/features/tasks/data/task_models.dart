import 'package:flutter/material.dart';
import '../../projects/data/project_models.dart';

/// Task Status constants and transitions
class TaskStatus {
  TaskStatus._();

  static const String backlog = 'backlog';
  static const String assigned = 'assigned';
  static const String inProgress = 'in_progress';
  static const String review = 'review';
  static const String changesRequired = 'changes_required';
  static const String completed = 'completed';

  static const List<String> all = [
    backlog,
    assigned,
    inProgress,
    review,
    changesRequired,
    completed,
  ];

  static const Map<String, List<String>> allowedTransitions = {
    backlog: [assigned, inProgress],
    assigned: [inProgress, backlog],
    inProgress: [review, changesRequired, completed],
    review: [changesRequired, completed, inProgress],
    changesRequired: [inProgress, review],
    completed: [inProgress], // reopen
  };

  static String label(String status) {
    switch (status.toLowerCase()) {
      case backlog:
        return 'Backlog';
      case assigned:
        return 'Assigned';
      case inProgress:
        return 'In Progress';
      case review:
        return 'In Review';
      case changesRequired:
        return 'Changes Req.';
      case completed:
        return 'Completed';
      default:
        return status;
    }
  }

  static Color color(String status) {
    switch (status.toLowerCase()) {
      case backlog:
        return const Color(0xFF64748B); // Slate
      case assigned:
        return const Color(0xFF0284C7); // Sky / Blue
      case inProgress:
        return const Color(0xFF2563EB); // Royal Blue
      case review:
        return const Color(0xFF8B5CF6); // Purple
      case changesRequired:
        return const Color(0xFFD97706); // Amber
      case completed:
        return const Color(0xFF10B981); // Emerald / Green
      default:
        return const Color(0xFF64748B);
    }
  }

  static IconData icon(String status) {
    switch (status.toLowerCase()) {
      case backlog:
        return Icons.inbox_outlined;
      case assigned:
        return Icons.assignment_ind_outlined;
      case inProgress:
        return Icons.play_circle_outline;
      case review:
        return Icons.rate_review_outlined;
      case changesRequired:
        return Icons.published_with_changes;
      case completed:
        return Icons.check_circle_outline;
      default:
        return Icons.task_alt;
    }
  }
}

/// Task Priority constants
class TaskPriority {
  TaskPriority._();

  static const String low = 'low';
  static const String medium = 'medium';
  static const String high = 'high';
  static const String urgent = 'urgent';

  static const List<String> all = [low, medium, high, urgent];

  static String label(String priority) {
    switch (priority.toLowerCase()) {
      case urgent:
        return 'Urgent';
      case high:
        return 'High';
      case low:
        return 'Low';
      case medium:
      default:
        return 'Medium';
    }
  }

  static Color color(String priority) {
    switch (priority.toLowerCase()) {
      case urgent:
        return const Color(0xFFDC2626); // Red
      case high:
        return const Color(0xFFEA580C); // Orange
      case medium:
        return const Color(0xFF2563EB); // Blue
      case low:
      default:
        return const Color(0xFF64748B); // Slate
    }
  }
}

/// Task Model representing a single task or subtask
class TaskItem {
  const TaskItem({
    required this.id,
    required this.companyId,
    required this.projectId,
    required this.title,
    this.parentTaskId,
    this.description,
    this.status = TaskStatus.backlog,
    this.priority = TaskPriority.medium,
    this.dueDate,
    this.isOverdue = false,
    this.daysRemaining,
    this.estimatedHours,
    this.actualHours = 0.0,
    this.timeVariance,
    this.startedAt,
    this.completedAt,
    this.assignedTo,
    this.createdBy,
    this.subtasksCount = 0,
    this.hasActiveTimer = false,
    this.activeTimer,
    this.createdAt,
    this.updatedAt,
  });

  final int id;
  final int companyId;
  final int projectId;
  final int? parentTaskId;
  final String title;
  final String? description;
  final String status;
  final String priority;
  final String? dueDate;
  final bool isOverdue;
  final int? daysRemaining;
  final double? estimatedHours;
  final double actualHours;
  final String? timeVariance;
  final String? startedAt;
  final String? completedAt;
  final TaskUserItem? assignedTo;
  final TaskUserItem? createdBy;
  final int subtasksCount;
  final bool hasActiveTimer;
  final ActiveTimerInfo? activeTimer;
  final String? createdAt;
  final String? updatedAt;

  bool get isSubtask => parentTaskId != null;
  bool get isCompleted => status == TaskStatus.completed;

  String get statusDisplay => TaskStatus.label(status);
  Color get statusColor => TaskStatus.color(status);
  IconData get statusIcon => TaskStatus.icon(status);

  String get priorityDisplay => TaskPriority.label(priority);
  Color get priorityColor => TaskPriority.color(priority);

  String get timeVarianceDisplay {
    if (timeVariance == 'early') return 'Under Est.';
    if (timeVariance == 'on_time') return 'On Time';
    if (timeVariance == 'over_time') return 'Over Est.';
    return 'Pending';
  }

  Color get timeVarianceColor {
    if (timeVariance == 'early') return const Color(0xFF10B981);
    if (timeVariance == 'on_time') return const Color(0xFF0284C7);
    if (timeVariance == 'over_time') return const Color(0xFFEF4444);
    return const Color(0xFF64748B);
  }

  String get deadlineDisplay {
    if (isCompleted) return 'Completed';
    if (dueDate == null) return 'No due date';
    if (isOverdue) {
      final days = daysRemaining != null ? daysRemaining!.abs() : 0;
      return days == 0 ? 'Due today' : 'Overdue by $days d';
    }
    if (daysRemaining != null) {
      if (daysRemaining == 0) return 'Due today';
      if (daysRemaining == 1) return 'Due tomorrow';
      return '$daysRemaining days left';
    }
    return dueDate!;
  }

  factory TaskItem.fromJson(Map<String, dynamic> json) {
    final assigned = json['assigned_to'] as Map<String, dynamic>?;
    final created = json['created_by'] as Map<String, dynamic>?;
    final timerJson = json['active_timer'] as Map<String, dynamic>?;

    return TaskItem(
      id: (json['id'] as num).toInt(),
      companyId: (json['company_id'] as num?)?.toInt() ?? 0,
      projectId: (json['project_id'] as num?)?.toInt() ?? 0,
      parentTaskId: (json['parent_task_id'] as num?)?.toInt(),
      title: json['title'] as String? ?? '',
      description: json['description'] as String?,
      status: json['status'] as String? ?? TaskStatus.backlog,
      priority: json['priority'] as String? ?? TaskPriority.medium,
      dueDate: json['due_date'] as String?,
      isOverdue: json['is_overdue'] as bool? ?? false,
      daysRemaining: (json['days_remaining'] as num?)?.toInt(),
      estimatedHours: (json['estimated_hours'] as num?)?.toDouble(),
      actualHours: (json['actual_hours'] as num?)?.toDouble() ?? 0.0,
      timeVariance: json['time_variance'] as String?,
      startedAt: json['started_at'] as String?,
      completedAt: json['completed_at'] as String?,
      assignedTo: assigned != null ? TaskUserItem.fromJson(assigned) : null,
      createdBy: created != null ? TaskUserItem.fromJson(created) : null,
      subtasksCount: (json['subtasks_count'] as num?)?.toInt() ?? 0,
      hasActiveTimer: json['has_active_timer'] as bool? ?? false,
      activeTimer: timerJson != null ? ActiveTimerInfo.fromJson(timerJson) : null,
      createdAt: json['created_at'] as String?,
      updatedAt: json['updated_at'] as String?,
    );
  }
}

/// Detailed Task with relations
class TaskDetail {
  const TaskDetail({
    required this.task,
    this.project,
    this.parentTask,
    this.subtasks = const [],
    this.timeEntries = const [],
    this.activities = const [],
  });

  final TaskItem task;
  final TaskProjectRef? project;
  final TaskParentRef? parentTask;
  final List<TaskItem> subtasks;
  final List<TimeEntryItem> timeEntries;
  final List<ProjectActivityItem> activities;

  factory TaskDetail.fromJson(Map<String, dynamic> json) {
    final taskItem = TaskItem.fromJson(json);
    final pJson = json['project'] as Map<String, dynamic>?;
    final parentJson = json['parent_task'] as Map<String, dynamic>?;

    final rawSubtasks = json['subtasks'] as List<dynamic>? ?? [];
    final subtasks = rawSubtasks
        .whereType<Map<String, dynamic>>()
        .map((s) => TaskItem.fromJson(s))
        .toList();

    final rawTimeEntries = json['time_entries'] as List<dynamic>? ?? [];
    final timeEntries = rawTimeEntries
        .whereType<Map<String, dynamic>>()
        .map((te) => TimeEntryItem.fromJson(te))
        .toList();

    final rawActivities = json['activities'] as List<dynamic>? ?? [];
    final activities = rawActivities
        .whereType<Map<String, dynamic>>()
        .map((a) => ProjectActivityItem.fromJson(a))
        .toList();

    return TaskDetail(
      task: taskItem,
      project: pJson != null ? TaskProjectRef.fromJson(pJson) : null,
      parentTask: parentJson != null ? TaskParentRef.fromJson(parentJson) : null,
      subtasks: subtasks,
      timeEntries: timeEntries,
      activities: activities,
    );
  }
}

/// Project Reference in Task Details
class TaskProjectRef {
  const TaskProjectRef({
    required this.id,
    required this.name,
    this.code,
    this.status = 'active',
    this.acceptsWork = true,
    this.managerId,
    this.teamLeadId,
  });

  final int id;
  final String name;
  final String? code;
  final String status;
  final bool acceptsWork;
  final int? managerId;
  final int? teamLeadId;

  factory TaskProjectRef.fromJson(Map<String, dynamic> json) {
    return TaskProjectRef(
      id: (json['id'] as num).toInt(),
      name: json['name'] as String? ?? '',
      code: json['code'] as String?,
      status: json['status'] as String? ?? 'active',
      acceptsWork: json['accepts_work'] as bool? ?? true,
      managerId: (json['manager_id'] as num?)?.toInt(),
      teamLeadId: (json['team_lead_id'] as num?)?.toInt(),
    );
  }
}

/// Parent Task Reference
class TaskParentRef {
  const TaskParentRef({
    required this.id,
    required this.title,
    this.status = 'backlog',
  });

  final int id;
  final String title;
  final String status;

  factory TaskParentRef.fromJson(Map<String, dynamic> json) {
    return TaskParentRef(
      id: (json['id'] as num).toInt(),
      title: json['title'] as String? ?? '',
      status: json['status'] as String? ?? 'backlog',
    );
  }
}

/// User Reference in Task & Time Entries
class TaskUserItem {
  const TaskUserItem({
    required this.id,
    required this.name,
    this.email,
    this.employeeCode,
    this.avatarUrl,
  });

  final int id;
  final String name;
  final String? email;
  final String? employeeCode;
  final String? avatarUrl;

  factory TaskUserItem.fromJson(Map<String, dynamic> json) {
    return TaskUserItem(
      id: (json['id'] as num).toInt(),
      name: json['name'] as String? ?? '',
      email: json['email'] as String?,
      employeeCode: json['employee_code'] as String?,
      avatarUrl: json['avatar_url'] as String?,
    );
  }
}

/// Active Timer information attached to Task
class ActiveTimerInfo {
  const ActiveTimerInfo({
    required this.id,
    this.startedAt,
    this.durationSeconds = 0,
  });

  final int id;
  final String? startedAt;
  final int durationSeconds;

  factory ActiveTimerInfo.fromJson(Map<String, dynamic> json) {
    return ActiveTimerInfo(
      id: (json['id'] as num).toInt(),
      startedAt: json['started_at'] as String?,
      durationSeconds: (json['duration_seconds'] as num?)?.toInt() ?? 0,
    );
  }
}

/// Time Tracking Entry Model
class TimeEntryItem {
  const TimeEntryItem({
    required this.id,
    required this.companyId,
    required this.projectId,
    required this.taskId,
    required this.userId,
    this.projectName,
    this.taskTitle,
    this.user,
    this.startedAt,
    this.endedAt,
    this.durationSeconds = 0,
    this.durationHours = 0.0,
    this.description,
    this.isManual = false,
    this.isRunning = false,
    this.createdAt,
  });

  final int id;
  final int companyId;
  final int projectId;
  final int taskId;
  final int userId;
  final String? projectName;
  final String? taskTitle;
  final TaskUserItem? user;
  final String? startedAt;
  final String? endedAt;
  final int durationSeconds;
  final double durationHours;
  final String? description;
  final bool isManual;
  final bool isRunning;
  final String? createdAt;

  String get durationFormatted {
    final hours = durationSeconds ~/ 3600;
    final mins = (durationSeconds % 3600) ~/ 60;
    final secs = durationSeconds % 60;
    if (hours > 0) {
      return '${hours}h ${mins}m';
    }
    if (mins > 0) {
      return '${mins}m ${secs}s';
    }
    return '${secs}s';
  }

  factory TimeEntryItem.fromJson(Map<String, dynamic> json) {
    final userJson = json['user'] as Map<String, dynamic>?;

    return TimeEntryItem(
      id: (json['id'] as num).toInt(),
      companyId: (json['company_id'] as num?)?.toInt() ?? 0,
      projectId: (json['project_id'] as num?)?.toInt() ?? 0,
      taskId: (json['task_id'] as num?)?.toInt() ?? 0,
      userId: (json['user_id'] as num?)?.toInt() ?? 0,
      projectName: json['project_name'] as String?,
      taskTitle: json['task_title'] as String?,
      user: userJson != null ? TaskUserItem.fromJson(userJson) : null,
      startedAt: json['started_at'] as String?,
      endedAt: json['ended_at'] as String?,
      durationSeconds: (json['duration_seconds'] as num?)?.toInt() ?? 0,
      durationHours: (json['duration_hours'] as num?)?.toDouble() ?? 0.0,
      description: json['description'] as String?,
      isManual: json['is_manual'] as bool? ?? false,
      isRunning: json['is_running'] as bool? ?? false,
      createdAt: json['created_at'] as String?,
    );
  }
}

/// Aggregated Task Metrics for Project Overview
class TaskMetrics {
  const TaskMetrics({
    this.totalTasks = 0,
    this.completedTasks = 0,
    this.inProgressTasks = 0,
    this.reviewTasks = 0,
    this.backlogTasks = 0,
    this.overdueTasks = 0,
    this.progressPercentage = 0,
    this.estimatedHoursTotal = 0.0,
    this.actualHoursTotal = 0.0,
  });

  final int totalTasks;
  final int completedTasks;
  final int inProgressTasks;
  final int reviewTasks;
  final int backlogTasks;
  final int overdueTasks;
  final int progressPercentage;
  final double estimatedHoursTotal;
  final double actualHoursTotal;

  double get progressRatio => totalTasks > 0 ? (completedTasks / totalTasks) : 0.0;

  factory TaskMetrics.fromJson(Map<String, dynamic> json) {
    return TaskMetrics(
      totalTasks: (json['total_tasks'] as num?)?.toInt() ?? 0,
      completedTasks: (json['completed_tasks'] as num?)?.toInt() ?? 0,
      inProgressTasks: (json['in_progress_tasks'] as num?)?.toInt() ?? 0,
      reviewTasks: (json['review_tasks'] as num?)?.toInt() ?? 0,
      backlogTasks: (json['backlog_tasks'] as num?)?.toInt() ?? 0,
      overdueTasks: (json['overdue_tasks'] as num?)?.toInt() ?? 0,
      progressPercentage: (json['progress_percentage'] as num?)?.toInt() ?? 0,
      estimatedHoursTotal: (json['estimated_hours_total'] as num?)?.toDouble() ?? 0.0,
      actualHoursTotal: (json['actual_hours_total'] as num?)?.toDouble() ?? 0.0,
    );
  }
}
