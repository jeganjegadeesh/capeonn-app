import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/network/api_client.dart';
import '../../../core/network/api_exception.dart';
import 'task_models.dart';

final taskRepositoryProvider = Provider<TaskRepository>((ref) {
  return TaskRepository(ref.watch(dioProvider));
});

class TaskRepository {
  TaskRepository(this._dio);

  final Dio _dio;

  /// GET /projects/{project}/tasks
  Future<List<TaskItem>> getProjectTasks(
    int projectId, {
    String? status,
    String? priority,
    String? assignedToId,
    bool? rootOnly,
    String? search,
    String? sortBy,
    String? sortDir,
  }) async {
    try {
      final params = <String, dynamic>{};
      if (status != null && status.isNotEmpty && status != 'all') params['status'] = status;
      if (priority != null && priority.isNotEmpty && priority != 'all') params['priority'] = priority;
      if (assignedToId != null && assignedToId.isNotEmpty && assignedToId != 'all') {
        params['assigned_to_id'] = assignedToId;
      }
      if (rootOnly != null) params['root_only'] = rootOnly ? 1 : 0;
      if (search != null && search.trim().isNotEmpty) params['search'] = search.trim();
      if (sortBy != null) params['sort_by'] = sortBy;
      if (sortDir != null) params['sort_dir'] = sortDir;

      final res = await _dio.get('/projects/$projectId/tasks', queryParameters: params);
      final raw = res.data['data'] as List<dynamic>? ?? [];
      return raw.whereType<Map<String, dynamic>>().map((t) => TaskItem.fromJson(t)).toList();
    } on DioException catch (e) {
      throw ApiException.fromDio(e);
    }
  }

  /// GET /tasks/my
  Future<List<TaskItem>> getMyTasks({
    String? status,
    int? projectId,
    String? priority,
    bool? isOverdue,
  }) async {
    try {
      final params = <String, dynamic>{};
      if (status != null && status.isNotEmpty && status != 'all') params['status'] = status;
      if (projectId != null) params['project_id'] = projectId;
      if (priority != null && priority.isNotEmpty && priority != 'all') params['priority'] = priority;
      if (isOverdue == true) params['is_overdue'] = 1;

      final res = await _dio.get('/tasks/my', queryParameters: params);
      final raw = res.data['data'] as List<dynamic>? ?? [];
      return raw.whereType<Map<String, dynamic>>().map((t) => TaskItem.fromJson(t)).toList();
    } on DioException catch (e) {
      throw ApiException.fromDio(e);
    }
  }

  /// GET /tasks/{task}
  Future<TaskDetail> getTask(int taskId) async {
    try {
      final res = await _dio.get('/tasks/$taskId');
      return TaskDetail.fromJson(Map<String, dynamic>.from(res.data['data'] as Map));
    } on DioException catch (e) {
      throw ApiException.fromDio(e);
    }
  }

  /// POST /projects/{project}/tasks
  Future<TaskItem> createTask(int projectId, Map<String, dynamic> data) async {
    try {
      final res = await _dio.post('/projects/$projectId/tasks', data: data);
      return TaskItem.fromJson(Map<String, dynamic>.from(res.data['data'] as Map));
    } on DioException catch (e) {
      throw ApiException.fromDio(e);
    }
  }

  /// PUT /tasks/{task}
  Future<TaskItem> updateTask(int taskId, Map<String, dynamic> data) async {
    try {
      final res = await _dio.put('/tasks/$taskId', data: data);
      return TaskItem.fromJson(Map<String, dynamic>.from(res.data['data'] as Map));
    } on DioException catch (e) {
      throw ApiException.fromDio(e);
    }
  }

  /// DELETE /tasks/{task}
  Future<void> deleteTask(int taskId) async {
    try {
      await _dio.delete('/tasks/$taskId');
    } on DioException catch (e) {
      throw ApiException.fromDio(e);
    }
  }

  /// POST /tasks/{task}/status
  Future<TaskItem> updateTaskStatus(int taskId, String status, {String? reason}) async {
    try {
      final data = <String, dynamic>{'status': status};
      if (reason != null && reason.trim().isNotEmpty) {
        data['reason'] = reason.trim();
      }
      final res = await _dio.post('/tasks/$taskId/status', data: data);
      return TaskItem.fromJson(Map<String, dynamic>.from(res.data['data'] as Map));
    } on DioException catch (e) {
      throw ApiException.fromDio(e);
    }
  }

  /// POST /tasks/{task}/assign
  Future<TaskItem> assignTask(int taskId, int? assignedToId) async {
    try {
      final res = await _dio.post('/tasks/$taskId/assign', data: {
        'assigned_to_id': assignedToId,
      });
      return TaskItem.fromJson(Map<String, dynamic>.from(res.data['data'] as Map));
    } on DioException catch (e) {
      throw ApiException.fromDio(e);
    }
  }

  /// GET /tasks/{task}/subtasks
  Future<List<TaskItem>> getSubtasks(int taskId) async {
    try {
      final res = await _dio.get('/tasks/$taskId/subtasks');
      final raw = res.data['data'] as List<dynamic>? ?? [];
      return raw.whereType<Map<String, dynamic>>().map((s) => TaskItem.fromJson(s)).toList();
    } on DioException catch (e) {
      throw ApiException.fromDio(e);
    }
  }

  /// POST /tasks/{task}/subtasks
  Future<TaskItem> createSubtask(int taskId, Map<String, dynamic> data) async {
    try {
      final res = await _dio.post('/tasks/$taskId/subtasks', data: data);
      return TaskItem.fromJson(Map<String, dynamic>.from(res.data['data'] as Map));
    } on DioException catch (e) {
      throw ApiException.fromDio(e);
    }
  }

  // ---------------------------------------------------------------------------
  // Time Tracking Endpoints
  // ---------------------------------------------------------------------------

  /// POST /tasks/{task}/timer/start
  Future<TimeEntryItem> startTimer(int taskId, {String? description}) async {
    try {
      final data = <String, dynamic>{};
      if (description != null && description.isNotEmpty) data['description'] = description;
      final res = await _dio.post('/tasks/$taskId/timer/start', data: data);
      return TimeEntryItem.fromJson(Map<String, dynamic>.from(res.data['data'] as Map));
    } on DioException catch (e) {
      throw ApiException.fromDio(e);
    }
  }

  /// POST /tasks/{task}/timer/stop
  Future<TimeEntryItem> stopTimer(int taskId, {String? description}) async {
    try {
      final data = <String, dynamic>{};
      if (description != null && description.isNotEmpty) data['description'] = description;
      final res = await _dio.post('/tasks/$taskId/timer/stop', data: data);
      return TimeEntryItem.fromJson(Map<String, dynamic>.from(res.data['data'] as Map));
    } on DioException catch (e) {
      throw ApiException.fromDio(e);
    }
  }

  /// GET /time-entries/active
  Future<TimeEntryItem?> getActiveTimer() async {
    try {
      final res = await _dio.get('/time-entries/active');
      final data = res.data['data'];
      if (data == null) return null;
      return TimeEntryItem.fromJson(Map<String, dynamic>.from(data as Map));
    } on DioException catch (e) {
      throw ApiException.fromDio(e);
    }
  }

  /// POST /tasks/{task}/time-entries
  Future<TimeEntryItem> storeManualTime(int taskId, Map<String, dynamic> data) async {
    try {
      final res = await _dio.post('/tasks/$taskId/time-entries', data: data);
      return TimeEntryItem.fromJson(Map<String, dynamic>.from(res.data['data'] as Map));
    } on DioException catch (e) {
      throw ApiException.fromDio(e);
    }
  }

  /// GET /time-entries
  Future<List<TimeEntryItem>> getTimeEntries({
    int? projectId,
    int? taskId,
    int? userId,
    bool? isManual,
    String? dateFrom,
    String? dateTo,
  }) async {
    try {
      final params = <String, dynamic>{};
      if (projectId != null) params['project_id'] = projectId;
      if (taskId != null) params['task_id'] = taskId;
      if (userId != null) params['user_id'] = userId;
      if (isManual != null) params['is_manual'] = isManual ? 1 : 0;
      if (dateFrom != null) params['date_from'] = dateFrom;
      if (dateTo != null) params['date_to'] = dateTo;

      final res = await _dio.get('/time-entries', queryParameters: params);
      final raw = res.data['data'] as List<dynamic>? ?? [];
      return raw.whereType<Map<String, dynamic>>().map((e) => TimeEntryItem.fromJson(e)).toList();
    } on DioException catch (e) {
      throw ApiException.fromDio(e);
    }
  }

  /// DELETE /time-entries/{entry}
  Future<void> deleteTimeEntry(int entryId) async {
    try {
      await _dio.delete('/time-entries/$entryId');
    } on DioException catch (e) {
      throw ApiException.fromDio(e);
    }
  }
}
